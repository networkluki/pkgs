NetworkLuki CyberLab uses Qt and Qt for Python (PySide6/Shiboken6) 6.12.0.
Qt libraries are Copyright (C) The Qt Company Ltd. and other contributors.
Applicable LGPL/GPL and third-party license texts are included in this directory.
Exact corresponding source archive filenames and SHA-256 values are in third-party-sources.json.
The application release includes those archives as separate downloadable assets.
The packaged application uses replaceable shared libraries in its _internal directory.
Keep the library filenames and architecture; use interface-compatible replacement builds.
Modification and reverse engineering for debugging changes to LGPL components are permitted.
Application source and packaging tools are distributed in the project's public repository.
